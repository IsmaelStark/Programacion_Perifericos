﻿namespace Calc_resistencia
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Calcular = new System.Windows.Forms.Button();
            this.Limpiar = new System.Windows.Forms.Button();
            this.Radiob3b = new System.Windows.Forms.RadioButton();
            this.Radiob4b = new System.Windows.Forms.RadioButton();
            this.Radiob5b = new System.Windows.Forms.RadioButton();
            this.Radiob6b = new System.Windows.Forms.RadioButton();
            this.Lb1 = new System.Windows.Forms.Label();
            this.Lb2 = new System.Windows.Forms.Label();
            this.Lb3 = new System.Windows.Forms.Label();
            this.Lb4 = new System.Windows.Forms.Label();
            this.Lb5 = new System.Windows.Forms.Label();
            this.Lb6 = new System.Windows.Forms.Label();
            this.list_b1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.list_b2 = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.list_b3 = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.list_b4 = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.list_b5 = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.list_b6 = new System.Windows.Forms.ListBox();
            this.list_b3_1 = new System.Windows.Forms.ListBox();
            this.lbl = new System.Windows.Forms.Label();
            this.list_b4_1 = new System.Windows.Forms.ListBox();
            this.lblR = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resistenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.capacitoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Calcular
            // 
            this.Calcular.Location = new System.Drawing.Point(15, 278);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(135, 31);
            this.Calcular.TabIndex = 0;
            this.Calcular.Text = "Carcular resistencia";
            this.Calcular.UseVisualStyleBackColor = true;
            this.Calcular.Click += new System.EventHandler(this.Calcular_Click);
            // 
            // Limpiar
            // 
            this.Limpiar.Location = new System.Drawing.Point(183, 278);
            this.Limpiar.Name = "Limpiar";
            this.Limpiar.Size = new System.Drawing.Size(127, 33);
            this.Limpiar.TabIndex = 1;
            this.Limpiar.Text = "Limpiar";
            this.Limpiar.UseVisualStyleBackColor = true;
            this.Limpiar.Click += new System.EventHandler(this.Limpiar_Click);
            // 
            // Radiob3b
            // 
            this.Radiob3b.AutoSize = true;
            this.Radiob3b.Location = new System.Drawing.Point(15, 40);
            this.Radiob3b.Name = "Radiob3b";
            this.Radiob3b.Size = new System.Drawing.Size(69, 17);
            this.Radiob3b.TabIndex = 2;
            this.Radiob3b.TabStop = true;
            this.Radiob3b.Text = "3 bandas";
            this.Radiob3b.UseVisualStyleBackColor = true;
            this.Radiob3b.CheckedChanged += new System.EventHandler(this.Radiob3b_CheckedChanged);
            // 
            // Radiob4b
            // 
            this.Radiob4b.AutoSize = true;
            this.Radiob4b.Location = new System.Drawing.Point(15, 62);
            this.Radiob4b.Name = "Radiob4b";
            this.Radiob4b.Size = new System.Drawing.Size(69, 17);
            this.Radiob4b.TabIndex = 3;
            this.Radiob4b.TabStop = true;
            this.Radiob4b.Text = "4 bandas";
            this.Radiob4b.UseVisualStyleBackColor = true;
            this.Radiob4b.CheckedChanged += new System.EventHandler(this.Radiob4b_CheckedChanged);
            // 
            // Radiob5b
            // 
            this.Radiob5b.AutoSize = true;
            this.Radiob5b.Location = new System.Drawing.Point(15, 85);
            this.Radiob5b.Name = "Radiob5b";
            this.Radiob5b.Size = new System.Drawing.Size(69, 17);
            this.Radiob5b.TabIndex = 4;
            this.Radiob5b.TabStop = true;
            this.Radiob5b.Text = "5 bandas";
            this.Radiob5b.UseVisualStyleBackColor = true;
            this.Radiob5b.CheckedChanged += new System.EventHandler(this.Radiob5b_CheckedChanged);
            // 
            // Radiob6b
            // 
            this.Radiob6b.AutoSize = true;
            this.Radiob6b.Location = new System.Drawing.Point(15, 108);
            this.Radiob6b.Name = "Radiob6b";
            this.Radiob6b.Size = new System.Drawing.Size(69, 17);
            this.Radiob6b.TabIndex = 5;
            this.Radiob6b.TabStop = true;
            this.Radiob6b.Text = "6 bandas";
            this.Radiob6b.UseVisualStyleBackColor = true;
            this.Radiob6b.CheckedChanged += new System.EventHandler(this.Radiob6b_CheckedChanged);
            // 
            // Lb1
            // 
            this.Lb1.BackColor = System.Drawing.Color.Black;
            this.Lb1.Location = new System.Drawing.Point(100, 39);
            this.Lb1.Name = "Lb1";
            this.Lb1.Size = new System.Drawing.Size(24, 49);
            this.Lb1.TabIndex = 6;
            // 
            // Lb2
            // 
            this.Lb2.BackColor = System.Drawing.Color.Black;
            this.Lb2.Location = new System.Drawing.Point(148, 39);
            this.Lb2.Name = "Lb2";
            this.Lb2.Size = new System.Drawing.Size(24, 49);
            this.Lb2.TabIndex = 7;
            // 
            // Lb3
            // 
            this.Lb3.BackColor = System.Drawing.Color.Black;
            this.Lb3.Location = new System.Drawing.Point(198, 39);
            this.Lb3.Name = "Lb3";
            this.Lb3.Size = new System.Drawing.Size(24, 49);
            this.Lb3.TabIndex = 8;
            // 
            // Lb4
            // 
            this.Lb4.BackColor = System.Drawing.Color.Black;
            this.Lb4.Location = new System.Drawing.Point(252, 39);
            this.Lb4.Name = "Lb4";
            this.Lb4.Size = new System.Drawing.Size(24, 49);
            this.Lb4.TabIndex = 9;
            // 
            // Lb5
            // 
            this.Lb5.BackColor = System.Drawing.Color.Maroon;
            this.Lb5.Location = new System.Drawing.Point(303, 39);
            this.Lb5.Name = "Lb5";
            this.Lb5.Size = new System.Drawing.Size(24, 49);
            this.Lb5.TabIndex = 10;
            // 
            // Lb6
            // 
            this.Lb6.BackColor = System.Drawing.Color.Maroon;
            this.Lb6.Location = new System.Drawing.Point(352, 39);
            this.Lb6.Name = "Lb6";
            this.Lb6.Size = new System.Drawing.Size(24, 49);
            this.Lb6.TabIndex = 11;
            // 
            // list_b1
            // 
            this.list_b1.FormattingEnabled = true;
            this.list_b1.Items.AddRange(new object[] {
            "Negro",
            "Cafe",
            "Rojo",
            "Naranja",
            "Amarillo",
            "Verde",
            "Azul",
            "Violeta",
            "Gris",
            "Blanco"});
            this.list_b1.Location = new System.Drawing.Point(12, 123);
            this.list_b1.Name = "list_b1";
            this.list_b1.Size = new System.Drawing.Size(61, 134);
            this.list_b1.TabIndex = 13;
            this.list_b1.SelectedIndexChanged += new System.EventHandler(this.list_b1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DimGray;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(2, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(477, 17);
            this.label1.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label2.Location = new System.Drawing.Point(43, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 69);
            this.label2.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label3.Location = new System.Drawing.Point(100, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(276, 49);
            this.label3.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label4.Location = new System.Drawing.Point(376, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 69);
            this.label4.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 15);
            this.label5.TabIndex = 18;
            this.label5.Text = "Banda 1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(103, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 15);
            this.label6.TabIndex = 20;
            this.label6.Text = "Banda 2";
            // 
            // list_b2
            // 
            this.list_b2.FormattingEnabled = true;
            this.list_b2.Items.AddRange(new object[] {
            "Negro",
            "Cafe",
            "Rojo",
            "Naranja",
            "Amarillo",
            "Verde",
            "Azul",
            "Violeta",
            "Gris",
            "Blanco"});
            this.list_b2.Location = new System.Drawing.Point(103, 123);
            this.list_b2.Name = "list_b2";
            this.list_b2.Size = new System.Drawing.Size(61, 134);
            this.list_b2.TabIndex = 19;
            this.list_b2.SelectedIndexChanged += new System.EventHandler(this.list_b2_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(183, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 15);
            this.label7.TabIndex = 22;
            this.label7.Text = "Banda 3";
            // 
            // list_b3
            // 
            this.list_b3.FormattingEnabled = true;
            this.list_b3.Items.AddRange(new object[] {
            "Negro",
            "Cafe",
            "Rojo",
            "Naranja",
            "Amarillo",
            "Verde",
            "Azul",
            "Violeta",
            "Gris",
            "Blanco"});
            this.list_b3.Location = new System.Drawing.Point(182, 124);
            this.list_b3.Name = "list_b3";
            this.list_b3.Size = new System.Drawing.Size(61, 134);
            this.list_b3.TabIndex = 21;
            this.list_b3.SelectedIndexChanged += new System.EventHandler(this.list_b3_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(266, 106);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 15);
            this.label8.TabIndex = 24;
            this.label8.Text = "Banda 4";
            // 
            // list_b4
            // 
            this.list_b4.FormattingEnabled = true;
            this.list_b4.Items.AddRange(new object[] {
            "Negro",
            "Cafe",
            "Rojo",
            "Naranja",
            "Amarillo",
            "Dorado",
            "Plata"});
            this.list_b4.Location = new System.Drawing.Point(266, 123);
            this.list_b4.Name = "list_b4";
            this.list_b4.Size = new System.Drawing.Size(61, 134);
            this.list_b4.TabIndex = 23;
            this.list_b4.SelectedIndexChanged += new System.EventHandler(this.list_b4_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(355, 106);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 15);
            this.label9.TabIndex = 26;
            this.label9.Text = "Banda 5";
            // 
            // list_b5
            // 
            this.list_b5.FormattingEnabled = true;
            this.list_b5.Items.AddRange(new object[] {
            "Cafe",
            "Rojo",
            "Dorado",
            "plata"});
            this.list_b5.Location = new System.Drawing.Point(355, 123);
            this.list_b5.Name = "list_b5";
            this.list_b5.Size = new System.Drawing.Size(61, 134);
            this.list_b5.TabIndex = 25;
            this.list_b5.SelectedIndexChanged += new System.EventHandler(this.list_b5_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(437, 106);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 15);
            this.label10.TabIndex = 28;
            this.label10.Text = "Banda 6";
            // 
            // list_b6
            // 
            this.list_b6.FormattingEnabled = true;
            this.list_b6.Items.AddRange(new object[] {
            "Cafe",
            "Rojo",
            "Amarillo",
            "Naranja",
            "Azul",
            "Violeta",
            "Blanco"});
            this.list_b6.Location = new System.Drawing.Point(437, 123);
            this.list_b6.Name = "list_b6";
            this.list_b6.Size = new System.Drawing.Size(61, 134);
            this.list_b6.TabIndex = 27;
            this.list_b6.SelectedIndexChanged += new System.EventHandler(this.list_b6_SelectedIndexChanged);
            // 
            // list_b3_1
            // 
            this.list_b3_1.FormattingEnabled = true;
            this.list_b3_1.Items.AddRange(new object[] {
            "Negro",
            "Cafe",
            "Rojo",
            "Naranja",
            "Amarillo",
            "Verde",
            "Azul",
            "Dorado",
            "Plata"});
            this.list_b3_1.Location = new System.Drawing.Point(182, 124);
            this.list_b3_1.Name = "list_b3_1";
            this.list_b3_1.Size = new System.Drawing.Size(61, 134);
            this.list_b3_1.TabIndex = 29;
            this.list_b3_1.SelectedIndexChanged += new System.EventHandler(this.list_b3_1_SelectedIndexChanged);
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.ForeColor = System.Drawing.Color.White;
            this.lbl.Location = new System.Drawing.Point(17, 332);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(96, 20);
            this.lbl.TabIndex = 30;
            this.lbl.Text = "Resultado:";
            // 
            // list_b4_1
            // 
            this.list_b4_1.FormattingEnabled = true;
            this.list_b4_1.Items.AddRange(new object[] {
            "Cafe",
            "Rojo",
            "Dorado",
            "Plata"});
            this.list_b4_1.Location = new System.Drawing.Point(266, 124);
            this.list_b4_1.Name = "list_b4_1";
            this.list_b4_1.Size = new System.Drawing.Size(61, 134);
            this.list_b4_1.TabIndex = 31;
            this.list_b4_1.SelectedIndexChanged += new System.EventHandler(this.list_b4_1_SelectedIndexChanged);
            // 
            // lblR
            // 
            this.lblR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR.ForeColor = System.Drawing.Color.White;
            this.lblR.Location = new System.Drawing.Point(119, 332);
            this.lblR.Name = "lblR";
            this.lblR.Size = new System.Drawing.Size(519, 20);
            this.lblR.TabIndex = 32;
            this.lblR.Text = "0 Ω";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(677, 24);
            this.menuStrip1.TabIndex = 33;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resistenciasToolStripMenuItem,
            this.capacitoresToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.archivoToolStripMenuItem.Text = "&Archivo";
            // 
            // resistenciasToolStripMenuItem
            // 
            this.resistenciasToolStripMenuItem.Name = "resistenciasToolStripMenuItem";
            this.resistenciasToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.resistenciasToolStripMenuItem.Text = "&Resistencias";
            // 
            // capacitoresToolStripMenuItem
            // 
            this.capacitoresToolStripMenuItem.Name = "capacitoresToolStripMenuItem";
            this.capacitoresToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.capacitoresToolStripMenuItem.Text = "Capacitores";
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ayudaToolStripMenuItem1});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.ayudaToolStripMenuItem.Text = "Ayuda";
            // 
            // ayudaToolStripMenuItem1
            // 
            this.ayudaToolStripMenuItem1.Name = "ayudaToolStripMenuItem1";
            this.ayudaToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.ayudaToolStripMenuItem1.Text = "&Ayuda";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Radiob4b);
            this.groupBox1.Controls.Add(this.Radiob3b);
            this.groupBox1.Controls.Add(this.Radiob5b);
            this.groupBox1.Controls.Add(this.Radiob6b);
            this.groupBox1.Location = new System.Drawing.Point(521, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(130, 144);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Selecciona el tipo de resistencia a calcular";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(677, 406);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblR);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.list_b6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.list_b5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.list_b2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Lb6);
            this.Controls.Add(this.Lb5);
            this.Controls.Add(this.Lb4);
            this.Controls.Add(this.Lb3);
            this.Controls.Add(this.Lb2);
            this.Controls.Add(this.Lb1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.list_b1);
            this.Controls.Add(this.Limpiar);
            this.Controls.Add(this.Calcular);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.list_b3);
            this.Controls.Add(this.list_b3_1);
            this.Controls.Add(this.list_b4);
            this.Controls.Add(this.list_b4_1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Calculadora de resistencias 2020";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Calcular;
        private System.Windows.Forms.Button Limpiar;
        private System.Windows.Forms.RadioButton Radiob3b;
        private System.Windows.Forms.RadioButton Radiob4b;
        private System.Windows.Forms.RadioButton Radiob5b;
        private System.Windows.Forms.RadioButton Radiob6b;
        private System.Windows.Forms.Label Lb1;
        private System.Windows.Forms.Label Lb2;
        private System.Windows.Forms.Label Lb3;
        private System.Windows.Forms.Label Lb4;
        private System.Windows.Forms.Label Lb5;
        private System.Windows.Forms.Label Lb6;
        private System.Windows.Forms.ListBox list_b1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox list_b2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox list_b3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox list_b4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox list_b5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox list_b6;
        private System.Windows.Forms.ListBox list_b3_1;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.ListBox list_b4_1;
        private System.Windows.Forms.Label lblR;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resistenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem capacitoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

