#include "main.h"
#define LED PIN_A1
#define DELAY 1000

void main(){
   unsigned char conteo=0, q = 7;
   setup_adc_ports(NO_ANALOGS, VSS_VDD);
   set_tris_e(0);          //todo salida
   set_tris_a(0b00001111); //0 para salidas, 1 para entradas
   set_tris_b(0x00);       //todo salida
   //set_tris_b(255);
   set_tris_d(0);          //todo salida
   
   //output_d(0b11001101);
   output_e(0b101);
   //set_tris_c(0b10111111);
   
   //delay_ms(5000);
   /*printf("Hola mundo....\n\r");
   printf("mi primer programa en un microcontrolador\n\r");
   printf("Para la materia de programacion de perifericos 2020\n\r");
   printf("y en cuarentena desde casa por la pandemia :'(\n\r\n\r");
   */
   
   
   lcd_init();
   lcd_putc("\fProgramacion de\nperifericos\nsimulacion luces\nAuto fantastico");
   delay_ms(500);
   lcd_putc("\f*****Ismael*****\n****Sanchez****");
   
   
   output_b(1);
   delay_ms(500);
   output_b(3);
   delay_ms(500);
   output_b(7);
   delay_ms(500);
   output_b(14);
   delay_ms(500);
   output_b(28);
   delay_ms(500);
   
   while(1){
      /*output_high(led1);
      delay_ms(100);
      output_low(led1);
      delay_ms(100);*/
      
      /*output_bit(led1,1);
      delay_ms(100);
      output_bit(led1,0);
      delay_ms(100);
      */
      
      
      /*for(int i =0;i<7;i++){
         output_b(q = q<<1);
         delay_ms(100);
      
      }
      for(int i =0;i<7;i++){
         output_b(q = q>>1);
         delay_ms(100);
      
      }*/
      
      //printf("%u\n\r",conteo++);
      //output_toggle(led1);
      //printf(lcd_putc,"\fConteo %u",conteo++);
      //delay_ms(500);
      
   }
}
