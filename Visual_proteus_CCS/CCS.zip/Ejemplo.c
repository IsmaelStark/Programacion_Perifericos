#include "main.h"
#define LED PIN_A1
#define DELAY 1000

void main(){
   unsigned char conteo=0, q = 7;
   
   char c;
   char string[22];
   
   
   setup_adc_ports(NO_ANALOGS, VSS_VDD);
   set_tris_e(0);          //todo salida
   set_tris_a(0b00001111); //0 para salidas, 1 para entradas
   set_tris_b(0x00);       //todo salida
   //set_tris_b(255);
   set_tris_d(0);          //todo salida
   
   //output_d(0b11001101);
   //output_e(0b101);
   //set_tris_c(0b10111111);
   
   //delay_ms(5000);
   /*printf("Hola mundo....\n\r");
   printf("mi primer programa en un microcontrolador\n\r");
   printf("Para la materia de programacion de perifericos 2020\n\r");
   printf("y en cuarentena desde casa por la pandemia :'(\n\r\n\r");
   */
   
   
   lcd_init();
   lcd_putc("\fProgramacion de\nperifericos\nsimulacion luces\nAuto fantastico");
   delay_ms(500);
   lcd_putc("\f*****Ismael*****\n****Sanchez****");
   
   
   /*output_b(1);
   delay_ms(500);
   output_b(3);
   delay_ms(500);
   output_b(7);
   delay_ms(500);
   output_b(14);
   delay_ms(500);
   output_b(28);
   delay_ms(500);
   */
   
   while(TRUE){
   
      //Enciendo y apago leds
      /*if(kbhit()){      //preguntamos si hay dato nuevo en puerto serial
         c = getc();    // se lee el nuevo dato por el puerto serial
         
         printf(lcd_putc,"\fRecibi la letra:\n%c",c);
         
         if(c =='a' || c == 'A'){   //si llego una 'a' o una 'A' encende led 1
            output_bit(led1,1);
            
         }else if(c =='B' || c == 'b'){   
            output_bit(led2,1);
            
         }else if(c =='c' || c == 'C'){  
            output_bit(led3,1);
            
         } else if(c =='d' || c == 'D'){   //si llego una d apaga led1
            output_bit(led1,0);
            
         }else if(c =='E' || c == 'e'){   
            output_bit(led2,0);
            
         }else if(c =='f' || c == 'F'){ 
            output_bit(led3,0);
            
         }else if(c =='T' || c == 't'){ 
            output_bit(led1,1);
            output_bit(led2,1);
            output_bit(led3,1);
            
         }else{
            output_bit(led1,0);
            output_bit(led2,0);
            output_bit(led3,0);
         }
      }*/
      
      //Muestro texto recibido por puerto seial
      if(kbhit()){
         gets(string);     //gets recibe carcateres y sale de esa funcion hasta que reciba un numero 13, \n
         printf(lcd_putc,"\f%s",string);
      }
     
      
      /*output_high(led1);
      delay_ms(100);
      output_low(led1);
      delay_ms(100);*/
      
      /*output_bit(led1,1);
      delay_ms(100);
      output_bit(led1,0);
      delay_ms(100);
      */
      
      
      /*for(int i =0;i<7;i++){
         output_b(q = q<<1);
         delay_ms(100);
      
      }
      for(int i =0;i<7;i++){
         output_b(q = q>>1);
         delay_ms(100);
      
      }*/
      
      //printf("%u\n\r",conteo++);
      //output_toggle(led1);
      //printf(lcd_putc,"\fConteo %u",conteo++);
      //delay_ms(500);
      
   }
}
