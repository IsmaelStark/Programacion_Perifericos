#opt compress     //para comprimir codigo, por default desactivada
#case 

#include <18F4550.h>
#device ADC=10
#fuses MCLR,XT,NOWDT,NOPROTECT,NOLVP,NODEBUG,USBDIV,PLL1,CPUDIV1,VREGEN
#fuses NOBROWNOUT//,BORV45
#use delay(clock=4M)
#use rs232(baud=9600,parity=N,stop=1,bits=8, UART1 ,STREAM=SERIAL)       //UART1 forzaa todo por hardware
//#use rs232(baud=9600,parity=N,xmit=PIN_C6,rcv=PIN_C7,bits=8,STREAM=SERIAL)

   #define LCD_DB4   PIN_D7
   #define LCD_DB5   PIN_D6 
   #define LCD_DB6   PIN_D5 
   #define LCD_DB7   PIN_D4 
   #define LCD_RS    PIN_D0 
   #define LCD_RW    PIN_D1 
   #define LCD_E     PIN_D2 
   
   #include "lcd20x4.c"
   //#include "..\Drivers\lcd20x4.c"
   

#define led1 PIN_E0
#define led2 PIN_E1
#define led3 PIN_E2
//!#define led5 pin_
//!#define led6 pin_
