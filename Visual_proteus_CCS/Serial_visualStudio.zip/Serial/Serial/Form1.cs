﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Serial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {   
           
        }

        private void bconect_Click(object sender, EventArgs e)
        {
            //serialPort1.Open();

            try
            {
                serialPort1.Open();
                groupBox1.Enabled = true;
                bconect.Enabled = false;
            }
            catch
            {
                MessageBox.Show("No existe el puerto o puerto no esta disponible");
            }
        }

        private void ldon_Click(object sender, EventArgs e)
        {
            serialPort1.Write("a");
        }

        private void ldoff_Click(object sender, EventArgs e)
        {
            serialPort1.Write("d");
        }

        private void bdesconectar_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            groupBox1.Enabled = false;
            bconect.Enabled = true;
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            button1.Location = new Point(0, 0);
            button1.Location = new Point(100, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sabia que aceptarias :v");
        }

        private void ldon2_Click(object sender, EventArgs e)
        {
            serialPort1.Write("b");
        }

        private void ldoff2_Click(object sender, EventArgs e)
        {
            serialPort1.Write("e");
        }

        private void ldon3_Click(object sender, EventArgs e)
        {
            serialPort1.Write("c");
        }

        private void ldoff3_Click(object sender, EventArgs e)
        {
            serialPort1.Write("f");
        }

        private void ldoffAll_Click(object sender, EventArgs e)
        {
            serialPort1.Write("x");
        }

        private void ldonAll_Click(object sender, EventArgs e)
        {
            serialPort1.Write("t");
            ///serialPort1.Write("a");
            //serialPort1.Write("b");
            //serialPort1.Write("c");
        }

        private void benviar_Click(object sender, EventArgs e)
        {
            serialPort1.Write(textBox1.Text);
            serialPort1.Write("\r");
        }
    }
}

// nota C# trabaja con unicode asi que cualquiera de estos caracteres los pueden copiar y pegar y los mostrara sin problemas
//https://www.rapidtables.com/code/text/unicode-characters.html
//
///Char	/ Unicode   /  Escape sequence / HTML numeric code   / HTML named code / Description
///  Ω	/ U+03A9	/     \u03A9	   /      &#937;	     /     &Omega;	   /  capital omega
///  

///en las propuiedades de sus formularios poner esta primera opcion por separado y vean que pasa:
///controlbox = False               // quita los botones de barra de titulo
///
/// o usar estas dos juntas
/// AutoSizeMode=GrowAndShrink      //no se puede redimenzionar con raton
/// MaximizeBox=false               //quita boton mximizar
/// 
/// FormBorderStyle                 //Quita la barra de titulo
/// .
/// .
/// En propiedades de formulario hacer esto:
/// StartPosition = CenterToScreen