﻿namespace Serial
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.bconect = new System.Windows.Forms.Button();
            this.bdesconectar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ldoff = new System.Windows.Forms.Button();
            this.ldon = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.benviar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ldon2 = new System.Windows.Forms.Button();
            this.ldoff2 = new System.Windows.Forms.Button();
            this.ldon3 = new System.Windows.Forms.Button();
            this.ldoff3 = new System.Windows.Forms.Button();
            this.ldoffAll = new System.Windows.Forms.Button();
            this.ldonAll = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bconect
            // 
            this.bconect.Location = new System.Drawing.Point(335, 12);
            this.bconect.Name = "bconect";
            this.bconect.Size = new System.Drawing.Size(83, 26);
            this.bconect.TabIndex = 0;
            this.bconect.Text = "Conectar";
            this.bconect.UseVisualStyleBackColor = true;
            this.bconect.Click += new System.EventHandler(this.bconect_Click);
            // 
            // bdesconectar
            // 
            this.bdesconectar.Location = new System.Drawing.Point(224, 160);
            this.bdesconectar.Name = "bdesconectar";
            this.bdesconectar.Size = new System.Drawing.Size(88, 30);
            this.bdesconectar.TabIndex = 1;
            this.bdesconectar.Text = "Desconectar";
            this.bdesconectar.UseVisualStyleBackColor = true;
            this.bdesconectar.Click += new System.EventHandler(this.bdesconectar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ldonAll);
            this.groupBox1.Controls.Add(this.ldoffAll);
            this.groupBox1.Controls.Add(this.ldoff3);
            this.groupBox1.Controls.Add(this.ldon3);
            this.groupBox1.Controls.Add(this.ldoff2);
            this.groupBox1.Controls.Add(this.ldon2);
            this.groupBox1.Controls.Add(this.ldoff);
            this.groupBox1.Controls.Add(this.ldon);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.benviar);
            this.groupBox1.Controls.Add(this.bdesconectar);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(312, 196);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Serial";
            // 
            // ldoff
            // 
            this.ldoff.Location = new System.Drawing.Point(112, 69);
            this.ldoff.Name = "ldoff";
            this.ldoff.Size = new System.Drawing.Size(78, 36);
            this.ldoff.TabIndex = 5;
            this.ldoff.Text = "LED off";
            this.ldoff.UseVisualStyleBackColor = true;
            this.ldoff.Click += new System.EventHandler(this.ldoff_Click);
            // 
            // ldon
            // 
            this.ldon.Location = new System.Drawing.Point(19, 69);
            this.ldon.Name = "ldon";
            this.ldon.Size = new System.Drawing.Size(81, 36);
            this.ldon.TabIndex = 4;
            this.ldon.Text = "LED on";
            this.ldon.UseVisualStyleBackColor = true;
            this.ldon.Click += new System.EventHandler(this.ldon_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(19, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(171, 20);
            this.textBox1.TabIndex = 3;
            // 
            // benviar
            // 
            this.benviar.Location = new System.Drawing.Point(224, 43);
            this.benviar.Name = "benviar";
            this.benviar.Size = new System.Drawing.Size(82, 20);
            this.benviar.TabIndex = 2;
            this.benviar.Text = "Enviar";
            this.benviar.UseVisualStyleBackColor = true;
            this.benviar.Click += new System.EventHandler(this.benviar_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(361, 172);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 71);
            this.button1.TabIndex = 3;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button1_MouseMove);
            // 
            // ldon2
            // 
            this.ldon2.Location = new System.Drawing.Point(19, 116);
            this.ldon2.Name = "ldon2";
            this.ldon2.Size = new System.Drawing.Size(81, 30);
            this.ldon2.TabIndex = 6;
            this.ldon2.Text = "LED2 on";
            this.ldon2.UseVisualStyleBackColor = true;
            this.ldon2.Click += new System.EventHandler(this.ldon2_Click);
            // 
            // ldoff2
            // 
            this.ldoff2.Location = new System.Drawing.Point(116, 118);
            this.ldoff2.Name = "ldoff2";
            this.ldoff2.Size = new System.Drawing.Size(74, 28);
            this.ldoff2.TabIndex = 7;
            this.ldoff2.Text = "LED2 off";
            this.ldoff2.UseVisualStyleBackColor = true;
            this.ldoff2.Click += new System.EventHandler(this.ldoff2_Click);
            // 
            // ldon3
            // 
            this.ldon3.Location = new System.Drawing.Point(19, 160);
            this.ldon3.Name = "ldon3";
            this.ldon3.Size = new System.Drawing.Size(81, 24);
            this.ldon3.TabIndex = 8;
            this.ldon3.Text = "LED3 on";
            this.ldon3.UseVisualStyleBackColor = true;
            this.ldon3.Click += new System.EventHandler(this.ldon3_Click);
            // 
            // ldoff3
            // 
            this.ldoff3.Location = new System.Drawing.Point(116, 156);
            this.ldoff3.Name = "ldoff3";
            this.ldoff3.Size = new System.Drawing.Size(74, 28);
            this.ldoff3.TabIndex = 9;
            this.ldoff3.Text = "LED3 off";
            this.ldoff3.UseVisualStyleBackColor = true;
            this.ldoff3.Click += new System.EventHandler(this.ldoff3_Click);
            // 
            // ldoffAll
            // 
            this.ldoffAll.Location = new System.Drawing.Point(222, 127);
            this.ldoffAll.Name = "ldoffAll";
            this.ldoffAll.Size = new System.Drawing.Size(84, 27);
            this.ldoffAll.TabIndex = 10;
            this.ldoffAll.Text = "Apagar todos";
            this.ldoffAll.UseVisualStyleBackColor = true;
            this.ldoffAll.Click += new System.EventHandler(this.ldoffAll_Click);
            // 
            // ldonAll
            // 
            this.ldonAll.Location = new System.Drawing.Point(224, 82);
            this.ldonAll.Name = "ldonAll";
            this.ldonAll.Size = new System.Drawing.Size(82, 39);
            this.ldonAll.TabIndex = 11;
            this.ldonAll.Text = "Encender todos";
            this.ldonAll.UseVisualStyleBackColor = true;
            this.ldonAll.Click += new System.EventHandler(this.ldonAll_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 401);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bconect);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Interfaz Serial Básica";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button bconect;
        private System.Windows.Forms.Button bdesconectar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button ldoff;
        private System.Windows.Forms.Button ldon;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button benviar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button ldoffAll;
        private System.Windows.Forms.Button ldoff3;
        private System.Windows.Forms.Button ldon3;
        private System.Windows.Forms.Button ldoff2;
        private System.Windows.Forms.Button ldon2;
        private System.Windows.Forms.Button ldonAll;
    }
}

